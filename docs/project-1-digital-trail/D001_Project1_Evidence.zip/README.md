# D001 Project 1 evidence package

Reference review 0.2. Run `node reproduce.mjs` from this directory using Node 22 or later. The delivered execution used Node 24.19.0. Regeneration writes the generated directory. Preserve the delivered copy before reproducing if comparing original bytes.

The seven pinned source bodies have their original identities in source-identities.json. MANIFEST.json records SHA-256 identities of delivered files except itself. Neither manifest nor hashes are signatures or physical release.

Fourteen checks exercise the local reference derivation, Store answer, nominal virtual sequence and specified faults. The virtual benchmark does not validate physical machine geometry. Physical admission is BLOCKED.

Controller_Reference.st and generated/Job1_Data.st are uncompiled source for engineering review. They require a TwinCAT project, the vendor libraries, declarations and axis references to be configured and checked. They are not an import-ready commissioned project. Do not map these diagnostic tool variables to physical outputs. No TwinCAT compilation or runtime execution is claimed.

Read document-source.md for ownership, numerical assumptions, detailed handoffs, the command ledger and outstanding evidence. No repository or operational Store pin was changed by this package.
