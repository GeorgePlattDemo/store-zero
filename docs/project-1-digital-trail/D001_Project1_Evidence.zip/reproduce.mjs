import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {evaluateUser1XBraceConfiguration, normalizeUser1XBraceConfiguration} from './system-source/user1-xbrace-rule.mjs';
import {loadCatalog, evaluateDimensionalStoreRequest} from './store-source/store-zero-stage2-store.mjs';
import {D001_TRAVEL_STANDARD as M, calculationHash, evaluateD001UserDefinedBoard} from './store-source/d001-travel-standard.mjs';

const ROOT=path.dirname(fileURLToPath(import.meta.url));
const OUT=path.join(ROOT,'generated');fs.mkdirSync(OUT,{recursive:true});
const PIN='9c62d9d6f7775deef83d47196d32c9b5174a352c';
const put=(n,v)=>fs.writeFileSync(path.join(OUT,n),JSON.stringify(v,null,2)+'\n');
for(const r of JSON.parse(fs.readFileSync(path.join(ROOT,'source-identities.json')))){
 const b=fs.readFileSync(path.join(ROOT,r.path));
 assert.equal(createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${b.length}\0`),b])).digest('hex'),r.blob);
}
export function requestFor(length=18,species='syp-treated'){
 const rule=evaluateUser1XBraceConfiguration(normalizeUser1XBraceConfiguration({partLengthIn:length}));
 if(!rule.valid) throw Error(rule.unresolvedReason);
 return {title:'Project 1 reference specimen',configurationId:rule.configurationId,configurationVersion:rule.configurationVersion,
 classId:'app.user-defined-board.v1',materialDemand:{species,form:'board',nominalT:2,nominalW:4},
 definedWorkpieceLengthIn:rule.derived.definedWorkpieceLengthIn.value,requiredOps:rule.derived.requiredOps,
 sawAngleDeg:rule.derived.angleDeg,cutPlane:rule.derived.cutPlane,datumCMethod:rule.derived.datumCMethod,
 declaredSawCuts:rule.derived.sawCuts,declaredSpotCount:rule.spotDemand.totalCount,
 unresolvedConditions:[],parts:rule.parts};
}
export function evaluate(d){return evaluateDimensionalStoreRequest(loadCatalog(),d,{requestId:'D001-REVIEW-0.2',evaluatedAt:'2026-10-04T03:00:00Z',storeRevision:PIN});}
export function moveTime(d,v,a){d=Math.abs(d);if(d===0)return 0;return d<=v*v/a?2*Math.sqrt(d/a):2*v/a+(d-v*v/a)/v;}
export function lower(d,answer){
 assert.equal(answer.status,'SUPPORTABLE');
 assert.equal(answer.evaluationReceipt.authority.storeRevision,PIN);
 assert.equal(answer.evaluationReceipt.demandHash,calculationHash(d));
 // Re-run the owning evaluator; do not accept a self-consistent but substituted answer.
 assert.equal(answer.calculationIdentity.resultHash,evaluate(d).calculationIdentity.resultHash);
 const operations=answer.estimate.travel.operationPlan;
 const local=operations.map(op=>({...op,sourceStoreOperationId:op.opId,sourceDemandHash:calculationHash(d)}));
 const parent=answer.materialResolution.workpieceLengthIn;
 let c=0,remaining=parent;const contacts=[];
 for(const op of local){
  if(op.kind==='REFERENCE_CUT')remaining-=M.control.kerfIn;
  if(op.kind==='INDEX')c=op.toCIn;
  if(op.kind==='REBASE_DATUM_C')c=0;
  contacts.push({operationId:op.opId,kind:op.kind,cMachineIn:c,remainingIn:remaining,
   R1:c<=24&&24<=c+remaining,M1:c<=30&&30<=c+remaining,R2:c<=48&&48<=c+remaining});
  if(op.kind==='MITER_CUTOFF')remaining=op.retainedAfterIn;
 }
 return {kind:'D001_REVIEW_LOCAL_JOB',version:'0.2',executionClass:'NOMINAL_COORDINATE_MODEL',
 definitionId:'SYO-USER1-XBRACE-0.1',definitionRevision:'SYO-USER1-XBRACE-0.1-v5',
 demandHash:calculationHash(d),storePin:PIN,storeCalculationIdentity:answer.calculationIdentity,
 machineConfigId:'D001-REFERENCE-REVIEW-0.2',physicalAuthority:false,operations:local,contacts,
 releaseBlockers:['ONE_ROLLER_CONTROL_UNRESOLVED','KERF_FACE_AND_REBASE_UNRESOLVED','SAW_STROKE_GEOMETRY_UNRESOLVED','COMMISSIONING_ABSENT']};
}
export function irFor(d,job){
 // Virtual test coordinates only. Nominal +Z is upward from the support plane.
 // Saw stroke distance is inherited from the earlier draft for benchmark comparison,
 // not asserted to be the physical downstroke distance of the proposed saw.
 const width=3.5,top=1.5,depth=M.spot.toolDiameterIn/2/Math.tan(M.spot.pointAngleDeg*Math.PI/360)+M.spot.fullDiameterDepthIn;
 const stroke=width/Math.cos(d.sawAngleDeg*Math.PI/180);
 let seq=[];const add=(kind,axis,target,v,a,source,extra={})=>seq.push({seq:seq.length+1,kind,axis,target,velocity:v,acceleration:a,source,...extra});
 add('DELAY',null,36,null,null,'STORE_HANDLING_LOAD',{seconds:36});
 add('MOVE','A',d.sawAngleDeg,30,120,'DEFINITION_ANGLE');
 add('DELAY',null,.1,null,null,'REFERENCE_ANGLE_SETTLE',{seconds:.1});
 add('DELAY',null,.25,null,null,'REFERENCE_CLAMP',{seconds:.25});
 let yPlaced=false;
 for(const op of job.operations){
  const source=op.opId;
  if(op.kind==='REFERENCE_CUT'||op.kind==='MITER_CUTOFF'){
   add('SET_SAW',null,1,null,null,source);
   add('MOVE','S',1.5,6,24,source);
   add('MOVE','S',1.5+stroke,3.6,24,source,{assumption:'UNVERIFIED_SAW_STROKE'});
   add('MOVE','S',0,6,24,source);
   add('DELAY',null,.05,null,null,source,{seconds:.05});
   add('SET_SAW',null,0,null,null,source);
   if(op.kind==='REFERENCE_CUT')add('CAPTURE_C',null,0,null,null,source,{seconds:.01,assumption:'NOMINAL_ZERO_REBASE'});
  } else if(op.kind==='INDEX'){
   add('MOVE_C','X',op.toCIn,8,32,source);
   add('VERIFY_X',null,op.toCIn,null,null,source,{seconds:.05});
  } else if(op.kind==='SPOT_ON_LOCATION'){
   if(!yPlaced){add('MOVE','Y',width/2,4,16,source);add('SET_SPOT',null,1,null,null,source);add('DELAY',null,.5,null,null,source,{seconds:.5});yPlaced=true;}
   add('MOVE','Z',top,2,16,source);
   add('MOVE','Z',top-depth,.4,16,source);
   add('MOVE','Z',top+.25,2,16,source);
  } else if(op.kind==='REBASE_DATUM_C')add('CAPTURE_C',null,0,null,null,source,{seconds:.01,assumption:'NOMINAL_ZERO_REBASE'});
 }
 add('SET_SPOT',null,0,null,null,'REFERENCE_END');
 add('DELAY',null,24,null,null,'STORE_HANDLING_RELEASE',{seconds:24});
 add('COMPLETE',null,0,null,null,'REFERENCE_END');
 return {version:'D001-VIRTUAL-IR-0.2',units:{linear:'in',angular:'deg',time:'s'},executionClass:'VIRTUAL_BENCH_ONLY',physicalAuthority:false,sequence:seq};
}
export function simulate(ir,{identityValid=true,slipAt=null,retractAt=null}={}){
 if(!identityValid)return {status:'REFUSED',reason:'JOB_IDENTITY_MISMATCH',motionCommands:0};
 let p={X:0,Y:0,Z:1.75,A:0,S:0},offset=0,t=0,trace=[],saw=false,spot=false,moveCount=0;
 for(const op of ir.sequence){
  if(op.seq===retractAt)return {status:'FAULT',reason:'TOOL_RETRACT_UNCONFIRMED',motionCommands:moveCount,trace};
  let dt=op.seconds||0,target=op.target;
  if(op.kind==='MOVE'||op.kind==='MOVE_C'){
   if(op.axis==='X'&&(p.S!==0||Math.abs(p.Z-1.75)>1e-9))throw Error('INDEX_WITH_TOOL_DOWN');
   if(op.kind==='MOVE_C')target=offset+op.target;
   dt=moveTime(target-p[op.axis],op.velocity,op.acceleration);p[op.axis]=target;moveCount++;
  } else if(op.kind==='CAPTURE_C')offset=p.X;
  else if(op.kind==='VERIFY_X'){
   if(op.seq===slipAt)return {status:'FAULT',reason:'POSITION_INVALID',motionCommands:moveCount,trace};
   assert.ok(Math.abs((p.X-offset)-op.target)<1e-9);
  } else if(op.kind==='SET_SAW')saw=!!op.target;
  else if(op.kind==='SET_SPOT')spot=!!op.target;
  trace.push({seq:op.seq,kind:op.kind,axis:op.axis,target:op.target,source:op.source,startSec:t,endSec:t+dt,durationSec:dt,positions:{...p},cOffset:offset,sawCommand:saw,spotCommand:spot});t+=dt;
 }
 return {status:'VIRTUAL_MODEL_COMPLETE',physicalAuthority:false,model:'ACCELERATION_LIMITED_STOP_TO_STOP',timeSec:t,motionCommands:moveCount,trace};
}
const demand=requestFor();const answer=evaluate(demand);const job=lower(demand,answer);const ir=irFor(demand,job);const sim=simulate(ir);
put('manufacturing-requirements.json',{kind:'REVIEW_MANUFACTURING_REQUIREMENTS',version:'0.2',adoptedInterface:false,definitionId:job.definitionId,definitionRevision:job.definitionRevision,sourceDemandHash:job.demandHash,storePin:PIN,storeResultHash:answer.calculationIdentity.resultHash,material:{requested:demand.materialDemand,resolvedSku:answer.materialResolution.storeSku,actualThicknessIn:1.5,actualWidthIn:3.5,parentLengthIn:72},parts:demand.parts,cutRequirements:{angleMagnitudeDeg:demand.sawAngleDeg,plane:'miter-face',endRelation:'parallel',lengthDatum:'long-long-outer-edge'},physicalAuthority:false});
put('definition-and-demand.json',{definitionId:job.definitionId,definitionRevision:job.definitionRevision,confirmationClass:'SOURCE_DRAFT_IDENTIFIES_CONFIRMED_REVISION_NOT_NEW_USER_CONFIRMATION',demand});
put('store-answer.json',answer);put('local-job.json',job);put('motion-ir.json',ir);put('virtual-trace.json',sim);
put('physical-admission.json',{status:'BLOCKED',physicalAuthority:false,reasons:job.releaseBlockers,motionCommands:0});
const legacyHash={inputHash:'30b6c02b11db30cf100be72ea4696c03b8ed7d2f217979c53cdae6ce73325e91',resultHash:'de1e0e0bdf0f77a6c5ea205191765ba0b846472fc0813fe71d9ddf28fd176333'};
const tstore=answer.estimate.travel.time.T_MACHINE_sec;
const priorReported=86.419536;
put('review-summary.json',{storeStatus:answer.status,storeSku:answer.materialResolution.storeSku,storeIdentity:answer.calculationIdentity,legacyReportedIdentity:legacyHash,
 legacyIdentityMatches:JSON.stringify(legacyHash)===JSON.stringify(answer.calculationIdentity),storeTimeSec:tstore,storeTotals:answer.estimate.totals,
 virtualTimeSec:sim.timeSec,deltaVirtualVsStoreSec:sim.timeSec-tstore,priorDraftReportedTimeSec:priorReported,
 deltaVirtualVsPriorDraftSec:sim.timeSec-priorReported,physicalAdmission:'BLOCKED',costPool:M.economics,
 sensitivities:[300,600,900,1200].map(h=>({productiveHours:h,sellRatePerHour:120000/h/.8,serviceUsd:Math.round(tstore/3600*120000/h/.8*100)/100})),
 evidenceClass:'EXECUTED_REFERENCE_SOFTWARE_AND_VIRTUAL_KINEMATIC_MODEL_NOT_TWINCAT_RUNTIME'});
fs.writeFileSync(path.join(OUT,'Job1_Data.st'),`(* Generated data for review only. Units in and deg. Not compiled. *)\nVAR_GLOBAL CONSTANT\n JobDemandHash : STRING(64) := '${job.demandHash}';\n StoreResultHash : STRING(64) := '${answer.calculationIdentity.resultHash}';\n PhysicalRelease : BOOL := FALSE;\nEND_VAR\nVAR_GLOBAL\n ReferenceIR : ARRAY[1..${ir.sequence.length}] OF ST_ReviewCommand := [\n`+ir.sequence.map(op=>` (Kind := ${ {MOVE:1,MOVE_C:2,CAPTURE_C:3,DELAY:4,VERIFY_X:5,SET_SAW:6,SET_SPOT:7,COMPLETE:8}[op.kind]}, AxisIndex := ${{X:0,Y:3,Z:4,A:5,S:6}[op.axis]??0}, Target := ${op.target.toFixed(12)}, Velocity := ${(op.velocity||0).toFixed(6)}, Acceleration := ${(op.acceleration||0).toFixed(6)}, DelaySeconds := ${(op.seconds||0).toFixed(6)})`).join(',\n')+'\n ];\nEND_VAR\n');
const proof=[];const check=(name,fn)=>{fn();proof.push({name,status:'PASS'});};
check('Seven repository source blobs match fetched Git object identities',()=>assert.equal(JSON.parse(fs.readFileSync(path.join(ROOT,'source-identities.json'))).length,7));
check('18 in definition derives 9 in spots and pinned Store Q 11.09',()=>{assert.equal(demand.parts[0].features[0].xIn,9);assert.equal(answer.estimate.totals.Q,11.09);});
check('Hypothetical 60 in workpiece fails retained-length rule and offered 72 in parent is selected',()=>{const item=loadCatalog().offerings.find(x=>x.storeSku===answer.materialResolution.storeSku);const r=evaluateD001UserDefinedBoard({item:{...item,stockL_in:60},storeRevision:PIN,demand:{configurationId:demand.configurationId,configurationVersion:demand.configurationVersion,classId:demand.classId,definedWorkpieceLengthIn:60,cut:{angleDeg:demand.sawAngleDeg,plane:'miter-face',kerfIn:.125},datumC:{method:'REFERENCE_CUT',stationId:'SAW-L'},parts:demand.parts,declaredSawCuts:3,declaredSpotCount:2,unresolvedConditions:[]}});assert.equal(r.status,'REFUSED');assert.ok(r.reasons.includes('LAST_REMAIN_BELOW_TWO_ROLLER_CONTROL'));assert.equal(answer.materialResolution.workpieceLengthIn,72);put('hypothetical-60-in-check.json',{evidenceClass:'COUNTERFACTUAL_LENGTH_CHECK_NOT_CATALOG_OFFERING',result:r});});
check('Forward spot placement equals station at both nominal targets',()=>{for(const op of job.operations.filter(x=>x.kind==='SPOT_ON_LOCATION')){const ix=job.operations.findIndex(x=>x.opId===op.opId);assert.ok(Math.abs(job.operations[ix-1].toCIn+op.workpieceFeatureXIn-36)<1e-9);}});
check('All 17 admitted length settings propagate through rule and Store',()=>{for(let l=16;l<=18;l+=.125){let d=requestFor(l),a=evaluate(d);assert.equal(d.parts[0].features[0].xIn,l/2);assert.equal(a.status,'SUPPORTABLE');assert.equal(a.estimate.travel.derivedSawCuts,3);assert.equal(a.estimate.travel.derivedSpotCount,2);}});
check('Outside-range and off-grid length rejected by System rule',()=>{assert.throws(()=>requestFor(18.125));assert.throws(()=>requestFor(16.01));});
check('Changed demand cannot reuse preceding answer',()=>assert.throws(()=>lower(requestFor(16),answer)));
check('Altered calculation identity rejected',()=>{let a=structuredClone(answer);a.calculationIdentity.resultHash='0'.repeat(64);assert.throws(()=>lower(demand,a));});
check('Wrong controller identity stops before motion',()=>assert.equal(simulate(ir,{identityValid:false}).motionCommands,0));
check('Position fault prevents following tool command',()=>{let s=simulate(ir,{slipAt:ir.sequence.find(x=>x.kind==='VERIFY_X').seq});assert.equal(s.status,'FAULT');assert.equal(s.reason,'POSITION_INVALID');});
check('Tool-retract fault stops model before next index',()=>{let s=simulate(ir,{retractAt:ir.sequence.find(x=>x.kind==='MOVE'&&x.axis==='S'&&x.target===0).seq});assert.equal(s.status,'FAULT');});
check('Nominal contact audit identifies single-roller states',()=>{assert.ok(job.contacts.some(x=>x.kind==='SPOT_ON_LOCATION'&&!x.R1&&x.R2));assert.ok(job.contacts.some(x=>x.kind==='MITER_CUTOFF'&&x.R1&&!x.R2));});
check('Finite kerf cannot be erased by changing coordinate label',()=>{const k=.125;const actualRetainedFaceAfterCut=k;assert.notEqual(actualRetainedFaceAfterCut,0);const currentMaster=-18;const faceAwareOffset=currentMaster-k;assert.equal(currentMaster-faceAwareOffset,k);});
check('Physical admission remains blocked with zero motion',()=>assert.equal(job.physicalAuthority,false));
put('proof-results.json',{passed:proof.length,failed:0,tests:proof,scope:'Local reference model only; repository-wide suites not rerun; TwinCAT not compiled'});
console.log(JSON.stringify({proofs:proof.length,status:answer.status,sku:answer.materialResolution.storeSku,totals:answer.estimate.totals,identity:answer.calculationIdentity,storeTimeSec:tstore,virtualTimeSec:sim.timeSec,physical:'BLOCKED'},null,2));
